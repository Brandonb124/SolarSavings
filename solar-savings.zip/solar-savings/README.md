# Solar Savings

A Pen created on CodePen.io. Original URL: [https://codepen.io/Barnardb96/pen/OJYKNwE](https://codepen.io/Barnardb96/pen/OJYKNwE).

